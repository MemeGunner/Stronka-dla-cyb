﻿
using Microsoft.AspNetCore.Identity;
using System.Globalization;
using System.Text.RegularExpressions;


namespace STRCYB.Models;

public static class PasswordPolicyValidator
{
    public static IdentityResult IsValid(string? password)
    {
        if (string.IsNullOrWhiteSpace(password))
            return IdentityResult.Failed(new IdentityError
            {
                Code = "InvalidPasswordNullOrWhite",
                Description = "Hasło nie może być puste ani zawierać pustych znaków jak spacja"
            });

        // Co najmniej 8 różnych znaków w haśle

        List<char> lista = new List<char>();
        foreach (char c in password)
        {
            if(!lista.Contains(c))
                lista.Add(c);
        }
        if (lista.Count < 8)
        {
            return IdentityResult.Failed(new IdentityError
            {
                Code = "InvalidPasswordCount",
                Description = "Hasło musi zawierać co najmniej 8 różnych znaków w haśle."
            });
        }

        

        return IdentityResult.Success;
    }
}
