﻿
using System.ComponentModel.DataAnnotations;

namespace STRCYB.Models;

public class AdminCreateUserViewModel
{
    [Required(ErrorMessage = "Podaj login.")]
    [StringLength(256)]
    public string UserName { get; set; } = "";

    [Required(ErrorMessage = "Podaj adres e-mail.")]
    [EmailAddress(ErrorMessage = "Niepoprawny adres e-mail.")]
    public string Email { get; set; } = "";

    [Required(ErrorMessage = "Podaj hasło początkowe.")]
    [RegularExpression(@"^[a-km-zA-HJ-NP-Z2-9]*$", ErrorMessage = "Bez znaków mylących (np. 0,O, I,1,l).")]
    [StringLength(10)]
    [DataType(DataType.Password)]
    public string Password { get; set; } = "";

    [Required(ErrorMessage = "Wybierz rolę.")]
    public string Role { get; set; } = "Czytelnik";
}
