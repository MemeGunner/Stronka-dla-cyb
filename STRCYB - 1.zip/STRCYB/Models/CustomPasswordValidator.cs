﻿
using STRCYB.Models;
using Microsoft.AspNetCore.Identity;

namespace STRCYB.Data;

public class CustomPasswordValidator : IPasswordValidator<ApplicationUser>
{
    public Task<IdentityResult> ValidateAsync(
        UserManager<ApplicationUser> manager,
        ApplicationUser user,
        string? password)
    {
        return Task.FromResult(PasswordPolicyValidator.IsValid(password));
    }
}
