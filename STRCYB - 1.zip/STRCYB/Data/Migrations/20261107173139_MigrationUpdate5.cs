﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace STRCYB.Data.Migrations
{
    /// <inheritdoc />
    public partial class MigrationUpdate5 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
